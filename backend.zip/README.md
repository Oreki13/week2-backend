# Backend Batch 11 QuikStart
using ExpressJS and mySQL

# Package
check package.json